package net.nusa.hibernate;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

/** @author Muhamad Sholihin **/

public class BookManager {
    protected SessionFactory sessionFactory;
    protected static Scanner scan = new Scanner(System.in);
 
    protected void setup() {
    	final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
    	        .configure()
    	        .build();
    	try {
    	    sessionFactory = new MetadataSources(registry).buildMetadata().buildSessionFactory();
    	} catch (Exception ex) {
    		ex.printStackTrace();
    	    StandardServiceRegistryBuilder.destroy(registry);
    	}
    }
 
    protected void exit() {
    	sessionFactory.close();
    }
 
    protected void create() {
        
    	System.out.println();
    	System.out.print("Masukkan judul buku: ");
    	String title = scan.next();
    	System.out.print("Masukkan penulis buku: ");
    	String author = scan.next();
    	System.out.print("Masukkan harga buku: ");
    	float price = scan.nextFloat();
    	
    	Book book = new Book();
    	book.setTitle(title);
    	book.setAuthor(author);
    	book.setPrice(price);
    	
    	Session session = sessionFactory.openSession();
    	session.beginTransaction();
    	
    	session.save(book);
    	
    	session.getTransaction().commit();
    	session.close();
    }
 
    protected void read() {
    	
    	System.out.println();
    	Session session = sessionFactory.openSession();
    	 
        long bookId = 1;
        Book book = session.get(Book.class, bookId);
     
        System.out.println("Judul: " + book.getTitle());
        System.out.println("Penulis: " + book.getAuthor());
        System.out.println("Harga: " + book.getPrice());
     
        session.close();
    }
 
    protected void update() {
    	
    	System.out.println();
    	System.out.print("Masukkan id buku yang akan diupdate: ");
    	long id = scan.nextInt();
    	System.out.print("Masukkan judul buku: ");
    	String title = scan.next();
    	System.out.print("Masukkan penulis buku: ");
    	String author = scan.next();
    	System.out.print("Masukkan harga buku: ");
    	float price = scan.nextFloat();
    	
    	Book book = new Book();
        book.setId(id);
        book.setTitle(title);
        book.setAuthor(author);
        book.setPrice(price);
     
        Session session = sessionFactory.openSession();
        session.beginTransaction();
     
        session.update(book);
     
        session.getTransaction().commit();
        session.close();
    }
 
    protected void delete() {
    	
    	System.out.println();
    	System.out.print("Masukkan id buku yang ingin dihapus: ");
    	long id = scan.nextInt();
    	
    	Book book = new Book();
        book.setId(id);
     
        Session session = sessionFactory.openSession();
        session.beginTransaction();
     
        session.delete(book);
     
        session.getTransaction().commit();
        session.close();
    }
 
    public static void main(String[] args) {
    	
    	BookManager manager = new BookManager();
        manager.setup();
        
    	System.out.println("Nusa Library CRUD Hibernate");
    	System.out.println("1. Create Buku");
    	System.out.println("2. Read Buku");
    	System.out.println("3. Update Buku");
    	System.out.println("4. Delete Buku");
    	System.out.println("5. Exit");
    	System.out.print("Masukkan menu pilihan: ");
    	int menu = scan.nextInt();
    	
    	switch(menu) {
    		case 1: manager.create();break;
    		case 2: manager.read();break;
    		case 3: manager.update();break;
    		case 4: manager.delete();break;
    		case 5: break;
    		default: System.out.println("Invalid input!");
    	}
    	
        manager.exit();
    }
}
