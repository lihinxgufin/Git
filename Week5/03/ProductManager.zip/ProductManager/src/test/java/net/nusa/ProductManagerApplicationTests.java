package net.nusa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
