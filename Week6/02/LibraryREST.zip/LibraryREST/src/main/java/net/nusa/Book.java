package net.nusa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/** @author Muhamad Sholihin **/

@Entity
public class Book {
	private Integer id;
	private String name;
	private Integer edition;
	private String publisher;
	private float price;
	private Integer pages;

	public Book() {

	}

	public Book(Integer id, String name, Integer edition, String publisher, float price, Integer pages) {
		this.id = id;
		this.name = name;
		this.edition = edition;
		this.publisher = publisher;
		this.price = price;
		this.pages = pages;
	}



	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getEdition() {
		return edition;
	}

	public void setEdition(Integer edition) {
		this.edition = edition;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Integer getPages() {
		return pages;
	}

	public void setPages(Integer pages) {
		this.pages = pages;
	}

	

}
