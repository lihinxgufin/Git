package net.nusa;

import org.springframework.data.jpa.repository.JpaRepository;

/** @author Muhamad Sholihin **/

public interface BookRepository extends JpaRepository<Book, Integer> {

}
