package com.nusa;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/** @author Muhamad Sholihin **/

public class Client {

	public static void main(String[] args) {
		
		// Menggunakan Cara Seperti Biasa
//		Student student = new Student();
//		student.setId(1);
//		student.setName("Lihin");
//		student.setAddress("Jakarta Pusat");
//		
//		System.out.println("Student Details: "+student);
		
		// Menggunakan BeanFactory
//		Resource resource = new ClassPathResource("studentbean.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);
		
//		Student s1 = (Student)factory.getBean("std1");
//		Student s2 = factory.getBean("std2", Student.class);
//		
//		System.out.println("Student Details: "+s1);
//		System.out.println("Student Details: "+s2);
		
		// Menggunakan Context
		ApplicationContext context = new ClassPathXmlApplicationContext("studentbean.xml");
		Student s1 = (Student)context.getBean("std1");
		
		System.out.println("Student Details: "+s1);
		
		ClassPathXmlApplicationContext cxt = (ClassPathXmlApplicationContext)context;
		cxt.close();
		
	}

}
