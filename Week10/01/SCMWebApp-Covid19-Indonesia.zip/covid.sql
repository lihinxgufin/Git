/*
 Navicat Premium Data Transfer

 Source Server         : MySQL Local
 Source Server Type    : MySQL
 Source Server Version : 100411
 Source Host           : localhost:3306
 Source Schema         : covid

 Target Server Type    : MySQL
 Target Server Version : 100411
 File Encoding         : 65001

 Date: 13/05/2020 19:23:42
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for item_brand
-- ----------------------------
DROP TABLE IF EXISTS `item_brand`;
CREATE TABLE `item_brand`  (
  `id_brand` int(11) NOT NULL,
  `code_brand` varchar(3) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nama_brand` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `shown` int(11) NOT NULL DEFAULT 1
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of item_brand
-- ----------------------------
INSERT INTO `item_brand` VALUES (1, 'IDT', 'IDT', 1);
INSERT INTO `item_brand` VALUES (2, 'PI', 'Pierce', 1);
INSERT INTO `item_brand` VALUES (3, 'SIG', 'Sigma', 1);

-- ----------------------------
-- Table structure for item_category
-- ----------------------------
DROP TABLE IF EXISTS `item_category`;
CREATE TABLE `item_category`  (
  `id_category` int(11) NOT NULL,
  `nama_category` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `code_category` varchar(2) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `shown` int(11) NOT NULL
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of item_category
-- ----------------------------
INSERT INTO `item_category` VALUES (2, 'Consumable Sekuensing', 'CS', 1);
INSERT INTO `item_category` VALUES (3, 'Tester', 'TE', 1);

-- ----------------------------
-- Table structure for item_distributor
-- ----------------------------
DROP TABLE IF EXISTS `item_distributor`;
CREATE TABLE `item_distributor`  (
  `id_distributor` int(11) NOT NULL,
  `nama_distributor` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `kode_distributor` varchar(8) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `shown` int(11) NOT NULL DEFAULT 1
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of item_distributor
-- ----------------------------
INSERT INTO `item_distributor` VALUES (1, 'BNPB DIPA', 'BDI', 1);
INSERT INTO `item_distributor` VALUES (2, 'BNPB DONOR', 'BDO', 1);

-- ----------------------------
-- Table structure for item_metrics
-- ----------------------------
DROP TABLE IF EXISTS `item_metrics`;
CREATE TABLE `item_metrics`  (
  `id_metrics` int(11) NOT NULL,
  `id_sub_cat` int(11) NOT NULL,
  `code_sub_cat` varchar(3) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `metric_name` varchar(16) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `metric_size` float NOT NULL,
  `metric_code` varchar(2) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of item_metrics
-- ----------------------------

-- ----------------------------
-- Table structure for item_sub_cat
-- ----------------------------
DROP TABLE IF EXISTS `item_sub_cat`;
CREATE TABLE `item_sub_cat`  (
  `id_sub_cat` int(11) NOT NULL,
  `id_cat` int(11) NOT NULL,
  `nama_sub_cat` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `code_sub_cat` varchar(5) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `shown` int(11) NOT NULL
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of item_sub_cat
-- ----------------------------

-- ----------------------------
-- Table structure for items
-- ----------------------------
DROP TABLE IF EXISTS `items`;
CREATE TABLE `items`  (
  `id_item` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `item_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `item_brand` varchar(48) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `item_kemasan` varchar(24) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `item_pieces_kemasan` int(11) NULL DEFAULT NULL,
  `item_metrics_pieces` varchar(24) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `id_category` int(11) NULL DEFAULT NULL,
  `created_at` datetime(0) NOT NULL DEFAULT current_timestamp(0),
  `updated_at` datetime(0) NOT NULL DEFAULT current_timestamp(0),
  `shown` int(11) NOT NULL DEFAULT 1,
  `created_by` int(11) NOT NULL DEFAULT 1,
  `id_brand` int(11) NULL DEFAULT NULL,
  `id_sub_cat` int(11) NULL DEFAULT NULL,
  `id_distributor` int(11) NULL DEFAULT NULL,
  `id_metrics` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id_item`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of items
-- ----------------------------
INSERT INTO `items` VALUES (1, NULL, 'DTT', NULL, 'Box', 15, 'Pcs', 2, '2020-05-10 15:26:11', '2020-05-10 15:26:11', 1, 1, 1, 1, 1, 1);
INSERT INTO `items` VALUES (2, NULL, 'Positive Control', NULL, 'Box', 8, 'Pcs', 2, '2020-05-10 23:44:59', '2020-05-10 23:44:59', 1, 1, 1, 1, 1, 1);
INSERT INTO `items` VALUES (3, NULL, 'DTT', NULL, 'Pack', 20, 'Pcs', 2, '2020-05-11 10:54:13', '2020-05-11 10:54:13', 1, 1, 2, 1, 1, 1);
INSERT INTO `items` VALUES (26, NULL, 'Test', NULL, 'Pack', 50, 'Pcs', 2, '2020-05-13 13:27:45', '2020-05-13 13:27:45', 1, 1, 2, 2, 2, 3);
INSERT INTO `items` VALUES (27, NULL, 'Dithiothreito', NULL, 'Botol', 20, 'ml', 2, '2020-05-13 13:47:06', '2020-05-13 13:47:06', 1, 1, 3, 1, 1, 1);

-- ----------------------------
-- View structure for v_items_brandcat
-- ----------------------------
DROP VIEW IF EXISTS `v_items_brandcat`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `v_items_brandcat` AS select `items`.`id_item` AS `id_item`,`items`.`item_code` AS `item_code`,`items`.`item_name` AS `item_name`,`items`.`item_brand` AS `item_brand`,`items`.`item_kemasan` AS `item_kemasan`,`items`.`item_pieces_kemasan` AS `item_pieces_kemasan`,`items`.`item_metrics_pieces` AS `item_metrics_pieces`,`items`.`id_category` AS `id_category`,`items`.`created_at` AS `created_at`,`items`.`updated_at` AS `updated_at`,`items`.`shown` AS `shown`,`items`.`created_by` AS `created_by`,`items`.`id_brand` AS `id_brand`,`items`.`id_sub_cat` AS `id_sub_cat`,`items`.`id_distributor` AS `id_distributor`,`items`.`id_metrics` AS `id_metrics`,`item_brand`.`nama_brand` AS `nama_brand`,`item_category`.`nama_category` AS `nama_category` from ((`items` join `item_brand` on((`item_brand`.`id_brand` = `items`.`id_brand`))) join `item_category` on((`items`.`id_category` = `item_category`.`id_category`))) where (`items`.`shown` = 1) ;

SET FOREIGN_KEY_CHECKS = 1;
