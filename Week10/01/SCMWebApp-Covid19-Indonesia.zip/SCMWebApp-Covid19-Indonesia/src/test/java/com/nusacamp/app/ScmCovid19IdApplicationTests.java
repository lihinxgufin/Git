package com.nusacamp.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScmCovid19IdApplicationTests {

	@Test
	void contextLoads() {
	}

}
