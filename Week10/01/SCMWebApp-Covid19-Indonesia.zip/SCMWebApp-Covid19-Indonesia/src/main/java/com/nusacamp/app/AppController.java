package com.nusacamp.app;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/** @author Muhamad Sholihin **/

@Controller
public class AppController {

	@Autowired
    private ItemsService service;
	@Autowired
    private ItemsViewService itemsViewService;
	@Autowired
	private ItemCategoryService categoryService;
	@Autowired
	private ItemBrandService brandService;
	@Autowired
	private ItemDistributorService distributorService;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {

	    List<ItemsView> listItemsView = itemsViewService.listAll();
	    model.addAttribute("listItemsView", listItemsView);
	    
	    return "index";
	}
	
	@RequestMapping("/new")
	public String showNewItemForm(Model model) {
		
	    List<ItemCategory> listCat = categoryService.listAll();
	    model.addAttribute("listCat",listCat);
	    
	    List<ItemBrand> listBrand = brandService.listAll();
	    model.addAttribute("listBrand",listBrand);
	    
	    List<ItemDistributor> listDist = distributorService.listAll();
	    model.addAttribute("listDist",listDist);
	    
		Items items = new Items();
		model.addAttribute("items", items);
		
		return "new_item";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveItem(@ModelAttribute("items") Items items) {
		service.save(items);
		
		return "redirect:/";
	}
	
	@RequestMapping("/edit/{id_item}")
	public ModelAndView showEditItemForm(@PathVariable(name = "id_item") Long id_item) {
		ModelAndView mav = new ModelAndView("edit_item");
		
		Items items = service.get(id_item);
		mav.addObject("items", items);
		
		return mav;
	}
	
}
