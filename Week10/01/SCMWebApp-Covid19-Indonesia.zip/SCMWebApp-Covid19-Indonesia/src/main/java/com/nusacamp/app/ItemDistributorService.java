package com.nusacamp.app;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** @author Muhamad Sholihin **/

@Service
@Transactional
public class ItemDistributorService {

	@Autowired
    private ItemDistributorRepository repo;
	
	public List<ItemDistributor> listAll() {
        return repo.findAll();
    }
}
