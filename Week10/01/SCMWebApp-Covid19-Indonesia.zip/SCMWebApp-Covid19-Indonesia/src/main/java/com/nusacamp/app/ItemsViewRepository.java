package com.nusacamp.app;

import org.springframework.data.jpa.repository.JpaRepository;

/** @author Muhamad Sholihin **/

public interface ItemsViewRepository extends JpaRepository<ItemsView, Long>{

}
