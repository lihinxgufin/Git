package com.nusacamp.app;

import org.springframework.data.jpa.repository.JpaRepository;

/** @author Muhamad Sholihin **/

public interface ItemCategoryRepository extends JpaRepository<ItemCategory, Long> {

}
