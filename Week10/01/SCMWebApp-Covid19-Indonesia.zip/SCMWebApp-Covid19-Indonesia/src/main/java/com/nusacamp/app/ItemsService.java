package com.nusacamp.app;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** @author Muhamad Sholihin **/

@Service
@Transactional
public class ItemsService {

	@Autowired
    private ItemsRepository repo;
	
	public List<Items> listAll() {
        return repo.findAll();
    }
	
	public void save(Items items) {
		repo.save(items);
	}
	
	public Items get(Long id_item) {
		return repo.findById(id_item).get();
	}
}
