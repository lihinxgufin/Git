package com.nusacamp.app;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** @author Muhamad Sholihin **/

@Entity
@Table(name = "item_category")
public class ItemCategory {

	private Long idCategory;
	private String namaCategory;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getIdCategory() {
		return idCategory;
	}

	public void setIdCategory(Long idCategory) {
		this.idCategory = idCategory;
	}

	public String getNamaCategory() {
		return namaCategory;
	}

	public void setNamaCategory(String namaCategory) {
		this.namaCategory = namaCategory;
	}
	
}
