package com.nusacamp.app;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** @author Muhamad Sholihin **/

@Entity
@Table(name = "item_brand")
public class ItemBrand {

	private Long idBrand;
	private String namaBrand;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getIdBrand() {
		return idBrand;
	}

	public void setIdBrand(Long idBrand) {
		this.idBrand = idBrand;
	}

	public String getNamaBrand() {
		return namaBrand;
	}

	public void setNamaBrand(String namaBrand) {
		this.namaBrand = namaBrand;
	}
	
	
}
