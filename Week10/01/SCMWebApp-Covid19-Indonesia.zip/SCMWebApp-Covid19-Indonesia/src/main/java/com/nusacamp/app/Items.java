package com.nusacamp.app;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/** @author Muhamad Sholihin **/

@Entity
public class Items {
	
	private Long idItem;
	private String itemCode;
	private String itemName;
	private String itemBrand;
	private String itemKemasan;
	private Integer itemPiecesKemasan;
	private String itemMetricsPieces;
	private Integer idCategory;
	private Integer idBrand;
	private Integer idSubCat;
	private Integer idDistributor;
	private Integer idMetrics;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getIdItem() {
		return idItem;
	}

	public void setIdItem(Long idItem) {
		this.idItem = idItem;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemBrand() {
		return itemBrand;
	}

	public void setItemBrand(String itemBrand) {
		this.itemBrand = itemBrand;
	}

	public String getItemKemasan() {
		return itemKemasan;
	}

	public void setItemKemasan(String itemKemasan) {
		this.itemKemasan = itemKemasan;
	}

	public Integer getItemPiecesKemasan() {
		return itemPiecesKemasan;
	}

	public void setItemPiecesKemasan(Integer itemPiecesKemasan) {
		this.itemPiecesKemasan = itemPiecesKemasan;
	}

	public String getItemMetricsPieces() {
		return itemMetricsPieces;
	}

	public void setItemMetricsPieces(String itemMetricsPieces) {
		this.itemMetricsPieces = itemMetricsPieces;
	}

	public Integer getIdCategory() {
		return idCategory;
	}

	public void setIdCategory(Integer idCategory) {
		this.idCategory = idCategory;
	}

	public Integer getIdBrand() {
		return idBrand;
	}

	public void setIdBrand(Integer idBrand) {
		this.idBrand = idBrand;
	}

	public Integer getIdSubCat() {
		return idSubCat;
	}

	public void setIdSubCat(Integer idSubCat) {
		this.idSubCat = idSubCat;
	}

	public Integer getIdDistributor() {
		return idDistributor;
	}

	public void setIdDistributor(Integer idDistributor) {
		this.idDistributor = idDistributor;
	}

	public Integer getIdMetrics() {
		return idMetrics;
	}

	public void setIdMetrics(Integer idMetrics) {
		this.idMetrics = idMetrics;
	}
		
}
