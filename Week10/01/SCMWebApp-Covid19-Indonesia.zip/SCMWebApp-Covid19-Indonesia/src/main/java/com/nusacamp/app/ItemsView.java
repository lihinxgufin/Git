package com.nusacamp.app;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** @author Muhamad Sholihin **/

@Entity
@Table(name = "v_items_brandcat")
public class ItemsView {

	private Long idItem;
	private String itemName;
	private String namaBrand;
	private String itemCode;
	private Integer itemPiecesKemasan;
	private String itemMetricsPieces;
	private String itemKemasan;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getIdItem() {
		return idItem;
	}

	public void setIdItem(Long idItem) {
		this.idItem = idItem;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getNamaBrand() {
		return namaBrand;
	}

	public void setNamaBrand(String namaBrand) {
		this.namaBrand = namaBrand;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public Integer getItemPiecesKemasan() {
		return itemPiecesKemasan;
	}

	public void setItemPiecesKemasan(Integer itemPiecesKemasan) {
		this.itemPiecesKemasan = itemPiecesKemasan;
	}

	public String getItemMetricsPieces() {
		return itemMetricsPieces;
	}

	public void setItemMetricsPieces(String itemMetricsPieces) {
		this.itemMetricsPieces = itemMetricsPieces;
	}

	public String getItemKemasan() {
		return itemKemasan;
	}

	public void setItemKemasan(String itemKemasan) {
		this.itemKemasan = itemKemasan;
	}
	
}
