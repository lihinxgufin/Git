package com.nusacamp.app;

import org.springframework.data.jpa.repository.JpaRepository;

/** @author Muhamad Sholihin **/

public interface ItemsRepository extends JpaRepository<Items, Long> {

}
