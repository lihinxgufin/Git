package com.nusacamp.app;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** @author Muhamad Sholihin **/

@Entity
@Table(name = "item_distributor")
public class ItemDistributor {

	private Long idDistributor;
	private String namaDistributor;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getIdDistributor() {
		return idDistributor;
	}

	public void setIdDistributor(Long idDistributor) {
		this.idDistributor = idDistributor;
	}

	public String getNamaDistributor() {
		return namaDistributor;
	}

	public void setNamaDistributor(String namaDistributor) {
		this.namaDistributor = namaDistributor;
	}
	
}
