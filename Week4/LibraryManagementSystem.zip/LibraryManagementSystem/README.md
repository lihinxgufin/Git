# Library_Management_System
An integrated library system (ILS), also known as a library management system (LMS), is an enterprise resource planning system for a library, used to track items owned, orders made, bills paid, and patrons who have borrowed.

In this project ypu can-

Issue Book
Return book
Calculate no. of days issued
Add new book
add new student
etc
