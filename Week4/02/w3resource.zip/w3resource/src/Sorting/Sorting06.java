/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sorting;

import java.util.Arrays;

/**
 *
 * @author Muhamad Sholihin
 */
public class Sorting06 {

//    Selection Sort

    public static void main(String[] args){
        int[] arr1 = {3,1,4,2,5};
        
        System.out.println("Original Array " + Arrays.toString(arr1));
        
        System.out.print("Sorted Array ");
        int[] arr2 = doSelectionSort(arr1);   
        for(int i:arr2){
            System.out.print(i);
            System.out.print(" ");
        }
    }
    
    public static int[] doSelectionSort(int[] arr){
         
        for (int i = 0; i < arr.length - 1; i++)
        {
            int index = i;
            for (int j = i + 1; j < arr.length; j++)
                if (arr[j] < arr[index]) 
                    index = j;
      
            int smallerNumber = arr[index];  
            arr[index] = arr[i];
            arr[i] = smallerNumber;
        }
        return arr;
    }
}

//6. Write a Java program to sort an array of given integers using Selection Sort Algorithm. Go to the editor

//According to Wikipedia "In computer science, selection sort is a sorting algorithm, specifically an in-place comparison sort. It has O(n2) time complexity, making it inefficient on large lists, and generally performs worse than the similar insertion sort".