/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sorting;

import java.util.Arrays;

/**
 *
 * @author Muhamad Sholihin
 */
public class Sorting07 {
    
//    Insertion Sort
    
    public static void main(String[] args){
        int[] arr1 = {3,1,4,2,5};
        
        System.out.println("Original Array " + Arrays.toString(arr1));
        
        System.out.print("Sorted Array ");
        int[] arr2 = doInsertionSort(arr1);
        for(int i:arr2){
            System.out.print(i);
            System.out.print(" ");
        }
    }
     
    public static int[] doInsertionSort(int[] input){
         
        int temp;
        for (int i = 1; i < input.length; i++) {
            for(int j = i ; j > 0 ; j--){
                if(input[j] < input[j-1]){
                    temp = input[j];
                    input[j] = input[j-1];
                    input[j-1] = temp;
                }
            }
        }
        return input;
    }
}

//7. Write a Java program to sort an array of given integers using Insertion sort Algorithm. Go to the editor
//
//Insertion sort is a simple sorting algorithm that builds the final sorted array (or list) one item at a time. It is much less efficient on large lists than other algorithms such as quicksort, heapsort, or merge sort.