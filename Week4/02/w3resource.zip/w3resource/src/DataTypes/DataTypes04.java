/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class DataTypes04 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input the number of minutes: ");
        int minute = scan.nextInt();
        int year = minute / 525960;
        int day = (minute / 1440) % 365;
        
        System.out.println(minute + " minutes is approximately " + year + " years and " + day + " days");
    }
}

//4. Write a Java program to convert minutes into a number of years and days. Go to the editor
//
//Test Data
//Input the number of minutes: 3456789
//Expected Output :
//3456789 minutes is approximately 6 years and 210 days