/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class DataTypes01 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input a degree in Fahrenheit: ");
        double fahrenheit = scan.nextDouble();
        double celcius = (fahrenheit - 32) / 1.8;
        
        System.out.println(fahrenheit + " degree Fahrenheit is equal to " + celcius + " in Celsius");
    }
}

//1. Write a Java program to convert temperature from Fahrenheit to Celsius degree. Go to the editor
//Test Data
//Input a degree in Fahrenheit: 212
//Expected Output:
//212.0 degree Fahrenheit is equal to 100.0 in Celsius