/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class DataTypes02 {
    
    private static DecimalFormat df = new DecimalFormat("#.#");
    
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input a value for inch: ");
        double inch = scan.nextDouble();
        double meter = inch / 39.370;
        
        System.out.println(inch + " inch is " + df.format(meter) + " meters");
    }
}

//2. Write a Java program that reads a number in inches, converts it to meters. Go to the editor
//Note: One inch is 0.0254 meter.
//Test Data
//Input a value for inch: 1000
//Expected Output :
//1000.0 inch is 25.4 meters