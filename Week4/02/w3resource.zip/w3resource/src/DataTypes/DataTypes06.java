/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class DataTypes06 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input weight in pounds: ");
        double weight = scan.nextDouble();
        System.out.print("Input height in inches: ");
        double height = scan.nextDouble();
        double bmi = 0.45359237 * weight / (height * 0.0254 * height * 0.0254);
        
        System.out.println("Body Mass Index is " + bmi);
    }
}

//6. Write a Java program to compute body mass index (BMI). Go to the editor
//
//Test Data
//Input weight in pounds: 452
//Input height in inches: 72
//Expected Output:
//Body Mass Index is 61.30159143458721