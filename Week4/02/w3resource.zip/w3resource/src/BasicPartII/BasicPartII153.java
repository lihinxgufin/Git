/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartII;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartII153 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input first number: ");
        int num1 = scan.nextInt();
        System.out.print("Input second number: ");
        int num2 = scan.nextInt();
        
        System.out.println(num1 >= 0 && num1 <= 1 && num2 >= 0 && num2 <= 1);
    }
}

//153. Write a Java program that accepts two double variables and test if both strictly between 0 and 1 and false otherwise. Go to the editor
//
//Sample Output:
//Input first number: 5
//Input second number: 1
//false