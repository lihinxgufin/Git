/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartII;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartII152 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input first number: ");
        int num1 = scan.nextInt();
        System.out.print("Input second number: ");
        int num2 = scan.nextInt();
        System.out.print("Input third number: ");
        int num3 = scan.nextInt();
        System.out.print("Input fourth number: ");
        int num4 = scan.nextInt();
        
        if((num1 == num2) && (num1 == num3) && (num1 == num4)){
            System.out.println("Numbers are equal");
        }else{
            System.out.println("Numbers are not equal!");
        }
    }
}

//152. Write a Java program that accepts four integer from the user and prints equal if all four are equal, and not equal otherwise. Go to the editor
//
//Sample Output:
//Input first number: 25
//Input second number: 37
//Input third number: 45
//Input fourth number: 23
//Numbers are not equal!