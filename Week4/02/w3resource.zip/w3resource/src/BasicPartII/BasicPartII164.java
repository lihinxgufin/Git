/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartII;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartII164 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Input the dividend: ");
        int dividend = scan.nextInt();
        System.out.print("Input the divider: ");
        int divider = scan.nextInt();
        
        double result = dividend / divider;
        System.out.println("Result: " + result);
    }
}

//164. Write a Java program to divide the two given integers using subtraction operator. Go to the editor
//
//Expected Output:
//Input the dividend: 625
//Input the divider: 25
//Result: 25.0