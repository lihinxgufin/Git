/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Search;

/**
 *
 * @author Muhamad Sholihin
 */
public class Search02 {
    
//    Linear Search
    
    public static void main(String[] args){
        int[] arr = {10,20,30,40,50};
        
        int key = 30;

        for (int i=0 ;i< arr.length-1; i++){
            if(arr[i]==key){
                System.out.println(key + " found at index: " + i);
            }
        }
    }
}

//2. Write a Java program to find a specified element in a given array of elements using Linear Search. Go to the editor
//Click me to see the solution