/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Search;

import java.util.Arrays;

/**
 *
 * @author Muhamad Sholihin
 */
public class Search01 {
    
//    Binary Search
    
    public static void main(String[] args){
        int[] arr = {10,20,30,40,50};
        
        int key = 30;
        
        System.out.println(key + " found at index "+Arrays.binarySearch(arr,key));
    }
}

//1. Write a Java program to find a specified element in a given array of elements using Binary Search. Go to the editor
//Click me to see the solution