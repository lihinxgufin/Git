/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartI;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartI06 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input first number: ");
        int num1 = scan.nextInt();
        System.out.print("Input second number: ");
        int num2 = scan.nextInt();
        
        int add = num1 + num2;
        int substract = num1 - num2;
        int multiply = num1 * num2;
        int divide = num1 / num2;
        int mod = num1 % num2;
        
        System.out.println(num1 +" + " + num2 +" = " + add);
        System.out.println(num1 +" - " + num2 +" = " + substract);
        System.out.println(num1 +" X " + num2 +" = " + multiply);
        System.out.println(num1 +" / " + num2 +" = " + divide);
        System.out.println(num1 +" mod " + num2 +" = " + mod);
    }
}

//6. Write a Java program to print the sum (addition), multiply, subtract, divide and remainder of two numbers. Go to the editor
//Test Data:
//Input first number: 125
//Input second number: 24
//Expected Output :
//125 + 24 = 149
//125 - 24 = 101
//125 x 24 = 3000
//125 / 24 = 5
//125 mod 24 = 5