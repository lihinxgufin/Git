/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartI;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartI03 {
    public static void main(String[] args){
        int num1 = 50;
        int num2 = 3;
        int hasil = num1 / num2;
        System.out.println(hasil);
    }
}

//3. Write a Java program to divide two numbers and print on the screen. Go to the editor
//Test Data :
//50/3
//Expected Output :
//16