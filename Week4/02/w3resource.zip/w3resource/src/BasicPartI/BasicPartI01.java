/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartI;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartI01 {
    public static void main(String[] args){
        
        System.out.println("Hello\nMuhamad Sholihin");
    }
}

//1. Write a Java program to print 'Hello' on screen and then print your name on a separate line. Go to the editor
//Expected Output :
//Hello
//Alexandra Abramov
