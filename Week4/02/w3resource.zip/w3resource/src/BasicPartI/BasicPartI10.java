/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartI;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartI10 {
    public static void main(String[] args){
        System.out.println(4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11)));
    }    
}
