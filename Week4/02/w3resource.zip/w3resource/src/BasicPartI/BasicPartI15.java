/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartI;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartI15 {
    public static void main(String[] args) {
        
        int num1 = 10;
        int num2 = 15;
        int temp;
        
        System.out.println("Before : num1 = "+num1+", num2 = "+ + num2);
        
        temp = num1;
        num1 = num2;
        num2 = temp;
        
        System.out.println("After: num1 = "+num1+", num2 = "+ + num2);
    }
}

//15. Write a Java program to swap two variables. Go to the editor
//Click me to see the solution