/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartI;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartI02 {
    public static void main(String[] args){
        int num1 = 74;
        int num2 = 36;
        int hasil = num1 + num2;
        System.out.println(hasil);
    }
}

//2. Write a Java program to print the sum of two numbers. Go to the editor
//Test Data:
//74 + 36
//Expected Output :
//110
