/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartI;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartI12 {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
   
        System.out.print("Input first number: ");
        int num1 = in.nextInt();
        System.out.print("Input second number: ");
        int num2 = in.nextInt();
        System.out.print("Input third number: ");
        int num3 = in.nextInt();
        
        System.out.println("Average: " + ((num1+num2+num3)/3));
    }
}

//12. Write a Java program that takes three numbers as input to calculate and print the average of the numbers. Go to the editor