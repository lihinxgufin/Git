/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartI;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartI08 {
    public static void main(String[] args){
        System.out.println("   J    a   v     v  a   ");
        System.out.println("   J   a a   v   v  a a  ");
        System.out.println("J  J  aaaaa   V V  aaaaa ");
        System.out.println(" JJ  a     a   V  a     a");
    }
}

//8. Write a Java program to display the following pattern. Go to the editor
//Sample Pattern :
//
//   J    a   v     v  a                                                  
//   J   a a   v   v  a a                                                 
//J  J  aaaaa   V V  aaaaa                                                
// JJ  a     a   V  a     a