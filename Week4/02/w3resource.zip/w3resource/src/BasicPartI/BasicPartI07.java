/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartI;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartI07 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input a number: ");
        int num = scan.nextInt();
        
        for (int i=0; i<10; i++){
            System.out.println(num +" X " + (i+1) +" = " + (num*(i+1)));
        }
    }
}

//7. Write a Java program that takes a number as input and prints its multiplication table upto 10. Go to the editor
//Test Data:
//Input a number: 8
//Expected Output :
//8 x 1 = 8
//8 x 2 = 16
//8 x 3 = 24
//...
//8 x 10 = 80