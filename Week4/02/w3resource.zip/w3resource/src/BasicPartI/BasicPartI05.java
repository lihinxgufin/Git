/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BasicPartI;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class BasicPartI05 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input first number: ");
        int num1 = scan.nextInt();
        System.out.print("Input second number: ");
        int num2 = scan.nextInt();
        int hasil = num1 * num2;
        
        System.out.println(num1 +" X " + num2 +" = " + hasil);
    }
}

//5. Write a Java program that takes two numbers as input and display the product of two numbers. Go to the editor
//Test Data:
//Input first number: 25
//Input second number: 5
//Expected Output :
//25 x 5 = 125