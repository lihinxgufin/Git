/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package String;

/**
 *
 * @author Muhamad Sholihin
 */
public class String12 {
    public static void main(String[] args){
        String str1 = "Python Exercises";
        String str2 = "Python Exercise";
        String end = "se";

        boolean end1 = str1.endsWith(end);
        boolean end2 = str2.endsWith(end);

        System.out.println("\"" + str1 + "\" ends with \"" + end + "\"? " + end1);
        System.out.println("\"" + str2 + "\" ends with \"" + end + "\"? " + end2);
    }
}

//12. Write a Java program to check whether a given string ends with the contents of another string. Go to the editor
//
//Sample Output:
//
//"Python Exercises" ends with "se"? false                                                                      
//"Python Exercise" ends with "se"? true