/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package String;

import java.util.Calendar;

/**
 *
 * @author Muhamad Sholihin
 */
public class String15 {
    public static void main(String[] args){
        Calendar cal = Calendar.getInstance();
        
        System.out.println("Current Date and Time :"); 
        System.out.format("%tB %te, %tY%n", cal, cal, cal);
        System.out.format("%tl:%tM %tp%n", cal, cal, cal);
    }
}

//15. Write a java program to print current date and time in the specified format. Go to the editor
//
//Sample Output:
//
//Current Date and Time :                                                                                       
//June 19, 2017                                                                                                 
//3:13 pm