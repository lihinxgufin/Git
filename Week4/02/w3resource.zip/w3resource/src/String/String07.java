/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package String;

/**
 *
 * @author Muhamad Sholihin
 */
public class String07 {
    public static void main(String[] args){
        String str1 = "PHP Exercises and ";
        String str2 = "Python Exercises";
        String str3 = str1.concat(str2);
        System.out.println("String 1: " + str1);
        System.out.println("String 2: " + str2);
        System.out.println("The concatenated string: " + str3);
    }
}

//7. Write a Java program to concatenate a given string to the end of another string. Go to the editor
//
//Sample Output:
//
//String 1: PHP Exercises and                                                                                   
//String 2: Python Exercises                                                                                    
//The concatenated string: PHP Exercises and Python Exercises