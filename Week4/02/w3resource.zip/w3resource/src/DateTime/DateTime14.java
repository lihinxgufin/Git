/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DateTime;

import java.time.LocalTime;

/**
 *
 * @author Muhamad Sholihin
 */
public class DateTime14 {
    public static void main(String[] args){
        LocalTime localTime = LocalTime.now();
        
        System.out.println("Local time: " + localTime);
    }
}

//14. Write a Java program to get the current local time. Go to the editor