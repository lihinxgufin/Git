/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DateTime;

import java.util.Calendar;

/**
 *
 * @author Muhamad Sholihin
 */
public class DateTime02 {
    public static void main(String[] args){
        Calendar cal = Calendar.getInstance();
        System.out.println("Year: " + cal.get(Calendar.YEAR));
        System.out.println("Month: " + cal.get(Calendar.MONTH));
        System.out.println("Day: " + cal.get(Calendar.DATE));
        System.out.println("Hour: " + cal.get(Calendar.HOUR));
        System.out.println("Minute: " + cal.get(Calendar.MINUTE));
    }
}

//2. Write a Java program to get and display information (year, month, day, hour, minute) of a default calendar. Go to the editor