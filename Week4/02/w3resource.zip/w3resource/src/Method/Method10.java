/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Method;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class Method10 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input a year: ");
        int year = scan.nextInt();
        
        System.out.println(isLeapYear(year));
        
    }
    
    public static boolean isLeapYear(int year){
        return ((year % 4 == 0) && ((year % 100) != 0) || ((year % 100 == 0) && (year % 400 == 0)));
    }
}

//10. Write a Java method to check whether a year (integer) entered by the user is a leap year or not. Go to the editor
//Expected Output:
//
//Input a year: 2017                                                                        
//false