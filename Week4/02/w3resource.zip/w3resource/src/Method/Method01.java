/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Method;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class Method01 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Input the first number: ");
        double num1 = scan.nextDouble();
        System.out.print("Input the second number: ");
        double num2 = scan.nextDouble();
        System.out.print("Input the third number: ");
        double num3 = scan.nextDouble();   
        
        System.out.println("The smallest value is " + smallest(num1, num2, num3));
    }
    
    public static double smallest(double num1, double num2, double num3){
        return Math.min(Math.min(num1, num2), num3);
    }
}

//1. Write a Java method to find the smallest number among three numbers. Go to the editor
//Test Data:
//Input the first number: 25
//Input the Second number: 37
//Input the third number: 29
//Expected Output:
//
//The smallest value is 25.0