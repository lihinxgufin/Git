/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Array;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Muhamad Sholihin
 */
public class Array21 {
    public static void main(String[] args){
        ArrayList<String> list = new ArrayList<String>();
        
        list.add("liverpool");
        list.add("chelsea");
        list.add("arsenal");
        list.add("mancity");
        list.add("tottenham");
        
        String[] arr = new String[5];
        list.toArray(arr);
        
        System.out.println("Array: " + Arrays.toString(arr));
    }
}

//21. Write a Java program to convert an ArrayList to an array. Go to the editor