/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Array;

import java.util.Arrays;

/**
 *
 * @author Muhamad Sholihin
 */
public class Array02 {
    public static void main(String[] args){
        int arr[] = {10, 20, 30, 40, 50};
        int sum = 0;
        
        for(int i : arr){
            sum += i;
        }
        System.out.println("Array: " + Arrays.toString(arr));
        System.out.println("Sum: " + sum);
    }
}

//2. Write a Java program to sum values of an array. Go to the editor