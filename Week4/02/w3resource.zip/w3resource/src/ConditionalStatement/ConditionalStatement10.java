/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConditionalStatement;

/**
 *
 * @author Muhamad Sholihin
 */
public class ConditionalStatement10 {
    public static void main(String[] args){
        System.out.println("The first 10 natural numbers are:\n");
        for(int i=1;i<=10;i++){
            System.out.println(i);
        }
    }
}

//10. Write a program in Java to display the first 10 natural numbers. Go to the editor
//
//Expected Output :
//
//The first 10 natural numbers are:                                                
//                                                                                 
//1                                                                                
//2                                                                                
//3                                                                                
//4                                                                                
//5                                                                                
//6                                                                                
//7                                                                                
//8                                                                                
//9                                                                                
//10