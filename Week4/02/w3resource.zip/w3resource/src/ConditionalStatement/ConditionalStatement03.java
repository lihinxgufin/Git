/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConditionalStatement;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class ConditionalStatement03 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input the 1st number: ");
        int num1 = scan.nextInt();
        System.out.print("Input the 2nd number: ");
        int num2 = scan.nextInt();
        System.out.print("Input the 3rd number: ");
        int num3 = scan.nextInt();
        
        if( num1 > num2 && num1 > num3){
            System.out.println("The greatest: " + num1);
        }else if (num2 > num1 && num2 > num3){
            System.out.println("The greatest: " + num2);
        }else{
            System.out.println("The greatest: " + num3);
        }
    }
}

//3. Take three numbers from the user and print the greatest number. Go to the editor
//
//Test Data
//Input the 1st number: 25
//Input the 2nd number: 78
//Input the 3rd number: 87
//Expected Output :
//The greatest: 87