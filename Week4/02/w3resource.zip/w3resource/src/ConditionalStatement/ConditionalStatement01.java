/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConditionalStatement;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class ConditionalStatement01 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input number: ");
        int num = scan.nextInt();
        
        if(num > 0){
            System.out.println("Number is positive");
        }else if(num < 0){
            System.out.println("Number is negative");
        }else{
            System.out.println("Number is zero");
        }
    }
}

//1. Write a Java program to get a number from the user and print whether it is positive or negative. Go to the editor
//
//Test Data
//Input number: 35
//Expected Output :
//Number is positive