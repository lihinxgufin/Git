/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConditionalStatement;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class ConditionalStatement05 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Input number: ");
        int num = scan.nextInt();        
        String day = "";
        switch (num) {
            case 1: day = "Monday"; break;
            case 2: day = "Tuesday"; break;
            case 3: day = "Wednesday"; break;
            case 4: day = "Thursday"; break;
            case 5: day = "Friday"; break;
            case 6: day = "Saturday"; break;
            case 7: day = "Sunday"; break;
            default:day = "Invalid day number";
        }
        System.out.println(day);
        
    }
}

//5. Write a Java program that keeps a number from the user and generates an integer between 1 and 7 and displays the name of the weekday. Go to the editor
//
//Test Data
//Input number: 3
//Expected Output :
//Wednesday