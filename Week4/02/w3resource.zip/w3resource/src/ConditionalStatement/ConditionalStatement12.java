/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConditionalStatement;

import java.util.Scanner;

/**
 *
 * @author Muhamad Sholihin
 */
public class ConditionalStatement12 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        
        int num = 0;
        int sum = 0;
        
        System.out.println("Input the 5 numbers : ");
        for(int i=0;i<5;i++){
            num = scan.nextInt();
            sum += num;
        }
        
        double average = sum/5;
        System.out.println("The sum of 5 no is : " + sum);
        System.out.println("The Average is : " + average);
    }
}

//12. Write a program in Java to input 5 numbers from keyboard and find their sum and average. Go to the editor
//Test Data
//Input the 5 numbers : 1 2 3 4 5
//Expected Output :
//
//Input the 5 numbers :                                                            
//1                                                                                
//2                                                                                
//3                                                                                
//4                                                                                
//5                                                                                
//The sum of 5 no is : 15                                                          
//The Average is : 3.0 