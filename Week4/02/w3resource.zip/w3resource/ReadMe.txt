Muhamad Sholihin
https://www.w3resource.com/java-exercises/