/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 50141
 Source Host           : localhost:3306
 Source Schema         : nusasorter

 Target Server Type    : MySQL
 Target Server Version : 50141
 File Encoding         : 65001

 Date: 18/03/2020 15:59:04
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for newbook
-- ----------------------------
DROP TABLE IF EXISTS `newbook`;
CREATE TABLE `newbook`  (
  `Book_ID` smallint(6) NULL DEFAULT NULL,
  `Name` varchar(21) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Edition` tinyint(4) NULL DEFAULT NULL,
  `Publisher` varchar(13) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Price` smallint(6) NULL DEFAULT NULL,
  `Pages` smallint(6) NULL DEFAULT NULL,
  `Bookshelf` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Image` longblob NULL
) ENGINE = MyISAM CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of newbook
-- ----------------------------
INSERT INTO `newbook` VALUES (141, 'Java', 1, 'Oracle Ltd', 999, 1299, 'Tech', NULL);
INSERT INTO `newbook` VALUES (280, 'OOPs', 5, 'Pranab', 896, 1233, 'Tech', NULL);
INSERT INTO `newbook` VALUES (284, 'Mathematics 3', 3, 'Goyal Ltd', 499, 868, 'Math', NULL);
INSERT INTO `newbook` VALUES (386, 'Discrete Mathematics', 5, 'Arnab Rash', 965, 1988, 'Math', NULL);
INSERT INTO `newbook` VALUES (537, 'Digital Electronics', 2, 'Prabjat ', 788, 2122, 'Tech', NULL);
INSERT INTO `newbook` VALUES (745, 'OS', 2, 'Windows', 1299, 1988, 'Tech', NULL);
INSERT INTO `newbook` VALUES (785, 'CBNST', 3, 'Laxmi Pvt Ltd', 299, 568, 'Tech', NULL);
INSERT INTO `newbook` VALUES (795, 'Data Structure With C', 7, 'Manish Goyal', 899, 598, 'Tech', NULL);
INSERT INTO `newbook` VALUES (805, 'HTML', 3, 'W3', 958, 1322, 'Tech', NULL);
INSERT INTO `newbook` VALUES (494, 'Drawing', 1, 'Art Inc', 999, 100, 'Art', NULL);
INSERT INTO `newbook` VALUES (974, 'Public Realtion', 1, 'John', 999, 100, 'Society', NULL);
INSERT INTO `newbook` VALUES (187, 'Mathem', 3, 'John', 799, 200, 'Math', NULL);

SET FOREIGN_KEY_CHECKS = 1;
