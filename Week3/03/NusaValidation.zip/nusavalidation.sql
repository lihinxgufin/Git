/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 50141
 Source Host           : localhost:3306
 Source Schema         : nusavalidation

 Target Server Type    : MySQL
 Target Server Version : 50141
 File Encoding         : 65001

 Date: 21/03/2020 14:28:18
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for nwstudent
-- ----------------------------
DROP TABLE IF EXISTS `nwstudent`;
CREATE TABLE `nwstudent`  (
  `Student_ID` smallint(6) NULL DEFAULT NULL,
  `Name` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Email` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Course` varchar(6) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Branch` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Year` tinyint(4) NULL DEFAULT NULL,
  `Semester` tinyint(4) NULL DEFAULT NULL
) ENGINE = MyISAM CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of nwstudent
-- ----------------------------
INSERT INTO `nwstudent` VALUES (417, 'Lihin', 'lihin@gmail.com', 'B.Tech', 'Math', 1, 2);

SET FOREIGN_KEY_CHECKS = 1;
