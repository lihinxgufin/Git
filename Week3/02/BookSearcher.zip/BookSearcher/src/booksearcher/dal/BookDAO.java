/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booksearcher.dal;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class BookDAO 
{
    Connection conn;
    ResultSet rs;
    Statement pst;
    
    public BookDAO(){
        Connect db = new Connect();
        db.ConnectDb();
        conn = db.conn;
        pst = db.pst;
    }
    
    private static final String wordFileName = "brit-a-z.txt";

    public List<String> getAllWords() throws FileNotFoundException 
    {
        
        ArrayList<String> words = new ArrayList<>();

        try{
            String sql="SELECT * FROM NEWBOOK";
            PreparedStatement pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
            while (rs.next()) {
                words.add(rs.getString("name"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        return words;
    }
    
}
