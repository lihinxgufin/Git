/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booksearcher.gui.controller;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import booksearcher.bll.BeginsWithSearch;
import booksearcher.bll.ContainsSearch;
import booksearcher.bll.EndsWithSearch;
import booksearcher.bll.BookManager;
import booksearcher.gui.model.BookModel;
import booksearcher.bll.IWordSearcher;

/**
 *
 * @author MS96
 */
public class MainController implements Initializable {

    @FXML
    private ListView lstWords;

    @FXML
    private TextField txtQuery;

    @FXML
    private RadioButton radioBegin;

    @FXML
    private ToggleGroup SearchTypes;

    @FXML
    private RadioButton radioContains;

    @FXML
    private RadioButton radioEnds;

    @FXML
    private RadioButton radioExact;

    @FXML
    private CheckBox chkCaseSensitive;

    private BookModel model;

    private BookManager wordManager;

    public MainController() {
        model = new BookModel();
        wordManager = new BookManager();
    }

    @FXML
    void handleSearch(ActionEvent event) {
        try {
            String query = txtQuery.getText().trim();
            List<String> searchResult = null;
            IWordSearcher searchStrategy;
            boolean isCaseSensitive = chkCaseSensitive.isSelected();
            if (radioBegin.isSelected()) {
                searchStrategy = new BeginsWithSearch(query, isCaseSensitive);
            } else if (radioContains.isSelected()) {
                searchStrategy = new ContainsSearch(query, isCaseSensitive);
            } else {
                searchStrategy = new EndsWithSearch(query, isCaseSensitive);
            }
            searchResult = wordManager.search(searchStrategy);

            model.setWords(searchResult);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        lstWords.setItems(model.getWords());
        
        try {
            List<String> allWords = wordManager.getAllWords();
            model.setWords(allWords);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

}
