/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booksearcher.gui.model;

import java.util.List;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author MS96
 */
public class BookModel {

    private final ObservableList<String> items;
    
    private final IntegerProperty count;

    public BookModel() 
    {
        items = FXCollections.observableArrayList();
        count = new SimpleIntegerProperty(-1);
    }

    public ObservableList<String> getWords() {
        return items;
    }

    public IntegerProperty getCount() {
        return count;
    }

    public void setWords(List<String> words)
    {
        items.clear();
        items.addAll(words);
        count.set(items.size());
    }
    
}